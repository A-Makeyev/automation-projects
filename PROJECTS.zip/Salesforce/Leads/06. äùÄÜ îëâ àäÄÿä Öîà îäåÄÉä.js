log.info(`06. הקמת ליד והמרה שלו להזמנה (${env.name != 'default' ? `${env.name} סביבת` : ''})`)
po.init(env.url, 120)

const leads = po.leads
const func = po.functions
const main = po.alphaMainPage

var phone = func.generatePhone()
var email = func.generateEmail()
var firstName = func.generateName()
const customerId = func.createTzNumber()
var lastName = `Automation - ${Math.random().toString().slice(2, 8)}`
var houseNumber = func.generateNumber(1, 9999)
var apartmentNumber = Math.trunc(houseNumber / 2)
var productNumber = env.name == 'PREP' ? '200707' : env.name == 'QA' ? '101994' : ''
var productNumber = '200707'

web.transaction('04. Close All Previous Tabs')
main.closeAllTabs()

web.transaction('05. Navigate To Leads')
main.openLeads()
web.waitForVisible('//a[@title="לידים"]')

web.transaction('06. Open New Lead Page')
main.closeAllTabs()
main.openLeads()
leads.openNewLeadWindow()

web.transaction('07. Fill Lead Details')
if (!web.isVisible(leads.firstName, po.shortWait)) {
    main.closeAllTabs()
    main.openLeads()

    if (web.isVisible(leads.newLeadBtn, po.shortWait)) po.click(leads.newLeadBtn)
    else po.click(leads.createNewLead)

    leads.assertLeadWindowError()
    web.waitForVisible('//strong[contains(text(), "פרטי הליד")]')
}

po.type(leads.firstName, firstName)
po.type(leads.lastName, lastName)
po.type(leads.phone, phone) 
func.pressTAB()

leads.handlePhoneError()

if (!web.isVisible('//input[@data-value="YES"]', po.shortWait)) {
    po.click(leads.handlingCompanyBtn)
    if (web.isVisible(leads.handlingCompany.yes)) {
        po.click(leads.handlingCompany.yes)
    }   
}

po.click(leads.interestedInBtn)
po.click(leads.interestedIn.yes)

if (web.isVisible(leads.customerConfirm, po.shortWait)) 
    po.click(leads.customerConfirm)


web.transaction('08. Create Lead')
web.waitForVisible(leads.finishLead)

web.execute(() => {
    document.evaluate(
        '//span[contains(text(), "סיום")]', document,
        null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
    ).singleNodeValue.click()
})

if (web.isVisible('//span[contains(text(), "התרחשה שגיאה")]', po.shortWait * 3)) {
    assert.fail('התרחשה שגיאה ביצירת ליד חדש')
}

web.transaction('09. Update Lead')
po.type(leads.offerGiven, 'yes ultimate')
func.pressTAB()

po.type(leads.offerTextArea, 'אחלה הצעה בסך הכל')

po.click(leads.status.interested)
web.clickHidden(leads.rivalCompanies.hot)

po.type(leads.emailInput, email)
po.type(leads.idInput, customerId)
func.pressTAB()

web.transaction('10. Find Customer')
po.click(leads.findCustomersBtn)

if (!web.isVisible('//button[text()="' + main.customerName + '"]', po.shortWait * 2)) {
    if (web.isVisible('//*[contains(text(), "קיימת הזמנה פתוחה למספר זיהוי")]', po.shortWait)) {
        po.click('//*[contains(text(), "סגירת ליד")]//..//*[@class="slds-radio_faux"]')
        po.click(leads.finishUpdateLead)
        assert.equal(
            web.isVisible('//*[@data-refid="tab-name" and @title="הסתיים"]'), true,
            'ליד עם תז ' + customerId + ' לא הסתיים בהצלחה'
        )
    }

    // יצירת חשבון חיוב חדש
    po.log('warning', 'לא נמצאו תוצאות ללקוח עם תז: ' + customerId)

    po.click('//*[contains(text(), "יצירת חשבון חיוב חדש")]//..//..//..//*[@class="slds-radio_faux"]')
    po.click(leads.finishUpdateLead)

    // if (web.isVisible('//*[@data-component-id="leadStatusUpdate"]//div[@class="spinner"]')) {
    //     assert.fail(`המערכת נתקעת בזמן יצירת חשבון חיוב חדש (${web.getUrl()})`)
    // }

    web.waitForVisible('//lightning-layout-item[@title="תהליך מכר"]')

    po.type('//label[contains(text(), "עיר")]//..//input', 'כפר סבא')
    po.click('//span[@role="option"]//span[contains(text(), "כפר סבא")]')

    po.type('//label[contains(text(), "רחוב")]//..//input', 'היוזמה')
    po.click('//span[@role="option"]//span[contains(text(), "היוזמה")]')

    po.type('//label[contains(text(), "מספר בית")]//..//input', '6')
    po.click('//span[contains(text(), "פרטי כתובות לקוח")]//..//..//..//..//..//span[@class="slds-radio_faux"]//..//span[contains(text(), "בניין")]')
    po.type('//label[contains(text(), "מספר דירה")]//..//input', '1') 
    po.type('//label[contains(text(), "כניסה")]//..//input', 'ללא כניסה')

    po.click('//*[(text()="הבא")]')
    if (web.isVisible('//*[contains(text(), "קיים לקוח AC  בכתובת")]', po.shortWait * 2)) {
        po.log('warning', 'כבר קיים לקוח בכתובת הזאת עם תז: ' + customerId)
    }

    web.pause(1) // CREATE NEW ADDRESS OR DELETE CUSTOMER

} else {
    po.click(`//button[text()="${main.customerName}"]//..//..//..//span[@class="slds-radio_faux"]`)
}

web.transaction('11. Finish Update Lead')
po.click(leads.finishUpdateLead)
func.refresh()

var orderNumber = web.getText('//div[contains(text(), "הזמנה")]//..//span[@class="uiOutputText"]')
po.log('success', `Order Number: ${orderNumber}`)

po.click('//label[contains(text(), "עיר")]//..//input')
po.type('//label[contains(text(), "עיר")]//..//input', 'כפר סבא')
po.click('//span[contains(text(), "כפר סבא")]')
po.click('//label[contains(text(), "רחוב")]//..//input')
po.type('//label[contains(text(), "רחוב")]//..//input', 'גביש')
po.click('//span[contains(text(), "גביש")]')

po.click('//*[contains(text(), "האם הלקוח גר בבניין או בבית פרטי")]//..//span[contains(text(), "בניין")]')

po.click('//label[contains(text(), "Email")]//..//input')
po.type('//label[contains(text(), "Email")]//..//input', email)
po.click('//label[contains(text(), "מספר דירה")]//..//input')
po.type('//label[contains(text(), "מספר דירה")]//..//input', houseNumber)
po.click('//label[contains(text(), "מספר בית")]//..//input')
po.type('//label[contains(text(), "מספר בית")]//..//input', apartmentNumber)
po.click('//button[contains(text(), "הבא") and not(@disabled)]')

web.waitForExist(`//*[@data-component-id="force_highlightsPanel"]//lightning-formatted-name[text()="${firstName} ${lastName}"]`)
if (web.isVisible('//div[contains(@class, "flexipageTabset")]//lightning-formatted-rich-text', po.shortWait * 2)) {
    po.log('info', web.getText('//div[contains(@class, "flexipageTabset")]//lightning-formatted-rich-text'))
}

po.click('//button[contains(text(), "הבא") and not(@disabled)]')

web.transaction('12.')
po.type('//label[contains(text(), "מילות מפתח או שם חבילה")]//..//input[@type="search"]', 'testo')
web.pause(1)

// if (web.isVisible('//*[contains(text(), "לא נמצאו הצעות המתאימות לחיפוש או לקו המטפל")]')) {
//     po.log('warning', `${customerId} :לא נמצאו הצעות המתאימות לחיפוש או לקו המטפל ללקוח עם תז`)
// }